<?php
declare(strict_types=1);

require_once __DIR__ . '/../src/Interfaces/MemberLendingRule.php';
require_once __DIR__ . '/../src/Strategies/MahasiswaRule.php';
require_once __DIR__ . '/../src/Strategies/DosenRule.php';
require_once __DIR__ . '/../src/Strategies/UmumRule.php';
require_once __DIR__ . '/../src/Strategies/MemberRuleFactory.php';
require_once __DIR__ . '/../src/Interfaces/DatabaseConnectionInterface.php';
require_once __DIR__ . '/../src/Interfaces/MailerInterface.php';
require_once __DIR__ . '/../src/Services/PerpustakaanService.php';
require_once __DIR__ . '/../src/Fakes/FakeDatabase.php';
require_once __DIR__ . '/../src/Fakes/FakeMailer.php';

$db = new FakeDatabase();
$mailer = new FakeMailer();
$perpus = new PerpustakaanService($db, $mailer);

echo "<h3>Data Peminjaman Perpustakaan</h3>";

echo "<b>1. Peminjaman Mahasiswa</b><br>";
$ruleMhs = MemberRuleFactory::create('mahasiswa');
$perpus->prosesPeminjaman($ruleMhs, 'budi@untan.ac.id', 10, 101);

echo "<br><b>2. Peminjaman Dosen</b><br>";
$ruleDosen = MemberRuleFactory::create('dosen');
$perpus->prosesPeminjaman($ruleDosen, 'hendra@untan.ac.id', 15, 202);

echo "<br><b>3. Tes Input Salah</b><br>";
try {
    $ruleTamu = MemberRuleFactory::create('tamu');
    $perpus->prosesPeminjaman($ruleTamu, 'tamu@gmail.com', 20, 303);
} catch (Exception $e) {
    echo "Gagal: " . $e->getMessage() . "<br>";
}
?>
