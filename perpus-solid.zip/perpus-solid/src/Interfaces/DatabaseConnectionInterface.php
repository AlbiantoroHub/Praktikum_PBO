<?php
declare(strict_types=1);

interface DatabaseConnectionInterface {
    public function exec(string $sql): bool;
}
?>
