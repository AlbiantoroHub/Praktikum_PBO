<?php
declare(strict_types=1);

interface MemberLendingRule {
    public function getLamaPinjam(): int;
    public function getTarifDenda(): int;
}
?>
