<?php
declare(strict_types=1);

interface MailerInterface {
    public function send(string $to, string $subject, string $message): void;
}
?>
