<?php
declare(strict_types=1);

class FakeMailer implements MailerInterface {
    public function send(string $to, string $subject, string $message): void {
        echo "Email terkirim ke $to ($subject): $message<br>";
    }
}
?>
