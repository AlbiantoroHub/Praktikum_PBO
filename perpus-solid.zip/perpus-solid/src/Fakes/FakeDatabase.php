<?php
declare(strict_types=1);

class FakeDatabase implements DatabaseConnectionInterface {
    public function exec(string $sql): bool {
        echo "Query: $sql<br>";
        return true;
    }
}
?>
