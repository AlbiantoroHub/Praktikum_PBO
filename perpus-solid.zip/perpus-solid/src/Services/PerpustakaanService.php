<?php
declare(strict_types=1);

class PerpustakaanService {
    public function __construct(
        private readonly DatabaseConnectionInterface $db,
        private readonly MailerInterface $mailer
    ) {}

    public function prosesPeminjaman(MemberLendingRule $rule, string $email, int $idBuku, int $idAnggota): void {
        $lamaPinjam = $rule->getLamaPinjam();
        $tarif = $rule->getTarifDenda();

        $this->db->exec("INSERT INTO peminjaman (id_buku, id_anggota, lama_pinjam) VALUES ($idBuku, $idAnggota, $lamaPinjam)");
        $this->mailer->send($email, 'Bukti Peminjaman', "Durasi pinjam $lamaPinjam hari, denda Rp$tarif/hari.");
    }
}
?>
