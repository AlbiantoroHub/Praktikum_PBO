<?php
declare(strict_types=1);

class DosenRule implements MemberLendingRule {
    public function getLamaPinjam(): int { return 14; }
    public function getTarifDenda(): int { return 500; }
}
?>
