<?php
declare(strict_types=1);

class MahasiswaRule implements MemberLendingRule {
    public function getLamaPinjam(): int { return 7; }
    public function getTarifDenda(): int { return 1000; }
}
?>
