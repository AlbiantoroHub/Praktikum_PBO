<?php
declare(strict_types=1);

final class MemberRuleFactory {
    public static function create(string $tipe): MemberLendingRule {
        return match(strtolower($tipe)) {
            'mahasiswa' => new MahasiswaRule(),
            'dosen' => new DosenRule(),
            'umum' => new UmumRule(),
            default => throw new InvalidArgumentException("Tipe anggota tidak dikenal: $tipe")
        };
    }
}
?>
