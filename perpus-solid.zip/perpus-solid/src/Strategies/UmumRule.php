<?php
declare(strict_types=1);

class UmumRule implements MemberLendingRule {
    public function getLamaPinjam(): int { return 3; }
    public function getTarifDenda(): int { return 2000; }
}
?>
